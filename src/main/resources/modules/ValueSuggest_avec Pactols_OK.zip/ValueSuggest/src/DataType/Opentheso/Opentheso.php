<?php
namespace ValueSuggest\DataType\Opentheso;

use ValueSuggest\DataType\AbstractDataType;
use ValueSuggest\Suggester\Opentheso\OpenthesoSuggest;

class Opentheso extends AbstractDataType
{
    public function getSuggester()
    {
        return new OpenthesoSuggest($this->services->get('Omeka\HttpClient'));
    }

    public function getName()
    {
        return 'valuesuggest:opentheso:opentheso';
    }

    public function getLabel()
    {
        return 'Opentheso: All Pactols of Frantiq'; // @translate
    }
}
